# focus
This app allows you to lock students to a specific webpage.
